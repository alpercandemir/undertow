package fixtures;
// Public demo contract: stable operation keys deduplicate charges; HALF_UP cents; no secrets in logs.
// OrderWriter is a separate Spring proxy. place() is not transactional. persist writes order then audit.
class Subject {
  java.net.http.HttpRequest place(java.net.URI uri) {
    return java.net.http.HttpRequest.newBuilder(uri).timeout(java.time.Duration.ofSeconds(5)).build();
  }
  Gateway gateway; Writer writer; Repository repository; Log log;
  record Money(java.math.BigDecimal amount) {}
  interface Gateway { boolean charge(String key, Money money); }
  interface Writer { void persist(Object order); }
  interface Repository { void save(Object order); void audit(Object order); }
  interface Log { void info(String format, Object value); }
  boolean retry(java.util.function.BooleanSupplier callback) { try { return callback.getAsBoolean(); } catch (IllegalStateException e) { return callback.getAsBoolean(); } }
  @org.springframework.transaction.annotation.Transactional
  void persist(Object order) { repository.save(order); repository.audit(order); }
  @org.springframework.transaction.annotation.Transactional
  private void privatePersist(Object order) { repository.save(order); repository.audit(order); }
}
