record Subject(int value) {}
