# Proposal: find reproducible business-behavior failures

Date: November 16, 2026.
Status: milestones 1–2 implemented and locally exercised on November 16, 2026. Milestone 3's technical path/internal validation and milestones 4–5's local packaging/documentation were implemented on November 17 following explicit authorization in the implementation chat. Independent rule review and product-value acceptance remain open. The November 17 CI-first revision below supersedes manual unaided adoption as a product gate. This record authorizes no deployment, model spending or removal of existing features.

## November 17 revision: CI execution, human decisions

The user replaced the manual unfamiliar-engineer command exercise with [automated GitHub Actions review](ci-behavior-review.md). Setup, baseline suites, search, replay, generated JUnit execution and disposable calibration adoption belong to CI. Engineers review the result, rule and test; an implementation agent applies accepted changes. The current acceptance criteria are [here](independent-review.md). Historical manual-onboarding criteria below describe the earlier plan and are superseded, not silently marked completed. Independent case selection and usefulness still require real evidence.

## Milestones 4–5 implementation record

The public local path is [`undertow explore`](explore.md), available through `./scripts/undertow explore` in a source checkout and `java -jar target/undertow.jar explore` in the packaged harness. The checkout path uses Python plus the selected component JDK without requiring the Java 25 harness to be built. The JAR bundles the same trusted Python runner, reviewed adapters and owned examples. Neither changes the frozen milestone 3 search core or adds execution to the read-only reviewer/MCP tools.

The command supports bounded search against compatible owned components, authored examples, identity-checked replay, and explicit JUnit draft adoption. Reports include readable HTML/Markdown, full observations, first violation, replay, draft test, proposed binding and an empty independent review record. Found/within-budget/incomplete outcomes have documented exit codes 1/0/2. Adoption verifies the generated source, rejects symlink traversal and existing tests, and copies one draft without changing contract policy. Optional owner approval continues through the unchanged contract initializer/importer/verifier path; generated files grant no policy or CI authority.

The public-command acceptance exercises all three profiles through both source and packaged entry points: generated failure and paired JUnit assertion/correction checks, replay, refusal to overwrite artifacts/tests, explicit adoption into fresh owned component copies, actual execution of adopted tests, completed bounded searches on corrections, and an uncompilable-subject result classified incomplete. Unit tests additionally cover modified draft payloads, changed oracle identities, nonfinding adoption, escaped report diagnostics, and exclusion of working-directory/PYTHONPATH modules from the packaged runtime.

Final verification passed 63 Python helper tests and 140 harness tests, formatting and zero High-threshold SpotBugs findings. The source and packaged smoke exercises each passed 19 public-command steps, plus actual Maven execution of the adopted tests. The frozen milestone 3 hashes remained intact. These are author-operated local checks, not independent adoption observations.

The README now leads with finding, replaying and adopting a reproducible behavior regression. The earlier contract/AI/hosted/assurance cookbook is preserved in [reference workflows](reference-workflows.md) with relocated links; existing features, tests and contract schemas remain in place. Reference roadmaps/status pages point to the current local path without erasing their specialist acceptance requirements. Hosted/AI feature expansion remains frozen.

This completes the authorized implementation and local documentation work, not the plan's empirical acceptance. No unfamiliar engineer has completed setup/adoption unaided, and no independent time-saving or broader detection claim is established. The generated `review.md` and [review procedure](explore.md#independent-adoption-review) leave those observations pending. The public explanation describes the implemented narrow workflow and internal evidence; product-value acceptance and independent adoption remain required before claiming the whole roadmap validated.

| Milestone | Implementation | Acceptance still open |
|---|---|---|
| 1 | Independent executable expectation and real Java adapter | Independent owner's expectation/adapter review |
| 2 | Generated discovery, reduction, replay and paired JUnit export | Local vertical slice passed |
| 3 | Retry behavior, second component and frozen internal validation | Independent cases/review and understanding-time assessment |
| 4 | Public command, reports, replay, explicit draft adoption and concise guide | Unfamiliar engineer completes the path without author operation |
| 5 | Primary documentation consolidated; historical workflows retained | Product positioning validated through observed independent usefulness |

## Milestone 3 execution record

See the [milestone 3 guide](../experiments/behavior-search/MILESTONE-3.md). Retry idempotency now uses explicit operation keys and the same bounded Java execution, reduction, replay and JUnit path. A shared declared-operation generator and simplifier were locked before second-adapter selection and validation-mutation authoring. The lock hashes the Python search core and strategy plus the Java transport/interface; it fixes validation seeds 211, 307 and 401. All lock hashes remained unchanged during the exercise.

The second component is the existing owned ticket-transfer fixture. Its adapter reads actual ownership/invitation state. Preview must be read-only, and only the recipient can accept, including after settlement. Harmless differences in duplicate-recipient return behavior are permitted. The second adapter required 57 Java adapter lines, 12 entry-point lines, a 132-line expectation/test exporter and a 16-line scenario definition. The frozen search/reduction algorithm and execution core were reused unchanged. These line counts record implementation footprint; active engineering time was not measured.

The internal validation retained eleven inputs: five suitable executable defects, three controls, and three excluded inputs (uncompilable source, reject-all suitability failure, and an unsupported concurrency request). All five eligible defects were generated, reduced and reproduced with all three locked seeds, with no misses or non-reproducing findings in this authored set. Every full search trace matched on a fresh JVM; reduced cases also replayed there. Each candidate's exported JUnit draft failed on its specific business assertion for that candidate and passed on the pristine correction.

Comparison with the exact existing fixture suites produced three additional failures in authored variants that pass those suites:

- A partial-refund retry charges the amount again: capture 2, refund key 1 for 1, then repeat the same operation; expected total 1, observed 2.
- Preview after recipient acceptance changes the settled ticket's owner.
- Acceptance by an unauthorized account can change a settled ticket's owner.

The unconditional preview-settlement mutation restated an existing assertion failure. A retry-rejection mutation caused an unexpected-exception result in the existing suite, so that comparison remains incomplete rather than being counted as an assertion-level baseline detection. The rejected/uncompilable inputs also retain their execution problems; out-of-scope concurrency was not executed. The three controls include a legitimate preview-copy change and completed without counterexamples.

Final local validation took **77.439 seconds**, including builds, existing suites, repeated searches and ten paired exported-test executions. All 55 Python helper tests, 139 harness tests with formatting/SpotBugs checks, and the original milestones 1–2 acceptance exercise passed. Standalone replay is supported for each explicit behavior profile.

This is self-authored internal validation, not independent engineer or blind held-out evidence: repository fixtures were visible during initial inspection. Independent expectation/adapter review, setup help and time to understand remain unmeasured. The next review should have another engineer reproduce a case unaided and assess whether the reproduction saves effort; stronger detection evidence needs independently prepared cases. Keep milestones 4–5 gated on that evidence rather than treating these local counts as general product validation.

## Milestones 1–2 execution record

The experimental implementation is in [`experiments/behavior-search/`](../experiments/behavior-search/README.md). It contains a separate Java 21 runner/adapter, an independent executable refund expectation, seeded bounded generation, reduction, fresh-state replay, local reports, and standalone JUnit export. The Java 25 harness and existing fixture/showcase remain unchanged.

Local acceptance used seeds 17, 29, and 101. Each found the cumulative-cap defect and reduced it to capture **2 minor units**, followed by refunds **1** and **2**: both were accepted, leaving **3** refunded. The corrected subject completed 100 generated scenarios per seed without a counterexample. Every search was repeated against the same compiled subject with fresh scenario state; hashes of all search observations matched. Original and reduced failures reproduced in fresh state. The same exported JUnit test failed specifically on the aggregate-cap assertion for the defect and passed on the correction.

The final six-search acceptance exercise, including repeated searches and the two exported JUnit executions, took **11.626 seconds** on the local toolchain. This excludes initial dependency downloads and repository-wide verification. Setup required populating Maven's missing plugin cache before offline execution. Implementation adds three Python modules and two small Java classes under the experiment, plus focused tests; it adds no package dependencies or harness Maven modules. Adapter observations come directly from the fixture's actual refunded counter and settled-operation map.

Validation passed: 44 Python helper tests (including 16 behavior-search tests), all 139 harness tests with formatting and SpotBugs checks, the existing six refund fixture tests, the paired exported JUnit exercise, and a standalone replay. Tests cover reject-all non-vacuity, unchanged state after rejection, stale binaries after build failure, unexpected exceptions, timeouts, and preservation of a verified original finding when reduction later encounters an execution problem. The existing HTTP-server test required execution outside the filesystem/network sandbox to bind its local socket.

Run the [acceptance command](../experiments/behavior-search/README.md#run-the-first-examples) to regenerate `examples.md`, per-subject reports, replay JSON, and the JUnit draft in a new ignored local output directory. The implementation is reviewable; an independent component owner's review and adoption are not inferred from these local checks. The existing refund tests already cover cap behavior, so this slice demonstrates generated discovery/reduction/reproduction, not an additional failure missed by current CI or general applicability. The product-review boundary here was followed by explicit authorization for the milestone 3 work recorded above.

## Decision to test

Keep the repository and reuse useful verification infrastructure. Develop one narrow workflow around finding a business-behavior failure in an implementation, reducing it to an understandable scenario, and exporting a regression test.

Initial user: an engineer replacing or extracting a stateful Java component. Initial question: “Can this implementation violate an approved business expectation, and can you give me a small example that reproduces it?”

The product hypothesis is that a reproducible scenario saves more investigation effort than another review report. Existing CI may already detect some failures; the pilot must measure what Undertow adds beyond those checks.

The first experiment uses the existing refund fixture. A second, independently selected component is required before treating the workflow as reusable or investing in packaging.

## User experience

The engineer selects a component, supplies a reviewed adapter and expectation, and runs a bounded search. Undertow returns:

- The business expectation that failed.
- Initial conditions and the reduced sequence of operations.
- Expected and observed behavior, with the first violating step.
- A replay artifact and an executable JUnit regression test.
- Search scope, assumptions, execution problems, and reproducibility details.

Example: “Against a capture of 100 units, refunds of 80 and 30 were both accepted. Total refunds exceeded the capture.” This illustrates the output; these specific inputs must not be embedded as the search algorithm's answer.

Use three outcomes: `counterexample_found`, `no_counterexample_within_budget`, and `incomplete`. A found result must reproduce. A completed search with no failure establishes only the observed bounded result. Build errors, timeouts, crashes, and unavailable observations remain execution problems unless an approved expectation explicitly defines that event as a violation. Report any unfinished search separately even when a valid failure was found.

Code locations and provenance are supporting details. The primary output is the behavior and its reproduction.

## First-release boundaries

Support one Java/Maven component per run, sequential in-memory state, explicit reset between scenarios, seeded bounded generation, and JUnit export. The first expectation is aggregate refunds never exceeding capture. Retry idempotency follows only after the first complete path works.

Use integer minor units and explicit ranges. Define which operations are valid, how rejected operations affect state, and which observations the adapter exposes. Preserve these decisions in the reviewed scenario definition.

Defer generic PR review, automatic business-rule discovery, arbitrary repository execution, concurrent/distributed behavior, provider integrations, additional languages, hosted accounts, billing, release/rollout policy, and a new web application. AI assistance and formal proof integration are later experiments, each requiring a demonstrated need.

An engineer reviews the expectation and adapter. The search cannot modify either to obtain success. Existing implementation behavior is evidence, not authority: legacy bugs must not become requirements automatically.

## Reuse and new work

| Area | Proposed treatment |
|---|---|
| Refund Java fixture | Reuse the real implementation and known broken/corrected variants for development. |
| Git identities, hashing, JSON/report utilities | Reuse where they fit; avoid introducing dependencies on the hosted service or AI reviewer. |
| Approved policy and evidence boundaries | Preserve their principles. Local search artifacts do not acquire trusted CI provenance. |
| Existing contract verifier | Keep as the evaluator of approved imported checks. Search is a separate operation; it does not change `satisfied` semantics. |
| Existing refund showcase | Retain as a recorded demonstration. Its fixed probe is not evidence of automatic discovery. |
| Generation, execution adapter, reduction, test export | New focused implementation. These are the main capability gap. |
| Hosted service, AI review, rollout features | Freeze feature expansion during the experiment; retain existing behavior and security tests. |
| Public demo and README | Update only after the new workflow works outside the original fixture. |

The harness uses JDK 25 while the refund fixture targets Java 21. Resolve this at the first milestone: a small separate test runner may be needed so a Java 21 application does not depend on the Java 25 CLI. Avoid a repository-wide module migration. Reuse must remain cheaper than coupling the experiment to unrelated infrastructure.

## Execution milestones

### 1. Establish an independent behavioral oracle

Write a short executable definition of the refund expectation and a minimal adapter: reset initial state, apply an operation, classify its result, and observe effects. Keep the expectation separate from the implementation under test. Document how observations relate to actual fixture state; an adapter returning its own expected totals would make the experiment circular.

Define non-vacuity checks: valid refunds must actually be accepted, rejected operations must leave the relevant state unchanged, and the cap must be reachable. These checks prevent an implementation that rejects every request from appearing useful merely because it never exceeds the cap.

Deliverables: reviewed scenario definition, adapter, execution protocol, and a short runtime decision. Provisional source location: `experiments/behavior-search/`; avoid exposing a stable public API yet.

Exit: the same scenario can execute against broken and corrected Java implementations with isolated state. Exceptions and execution failures have explicit classifications. No browser-model result substitutes for Java execution.

### 2. Find, reduce, and replay one failure

Implement seeded generation of bounded operation sequences, emphasizing boundary values and accumulated state. Build once per subject where practical; reset for every scenario. Record seed, generator version, budgets, subject and oracle identities, and actual execution counts.

Add a reducer that removes operations and simplifies values while preserving valid preconditions and the same violated expectation. Bound reduction time. Call the result “reduced,” not globally minimal. Re-run both the original failure and the reduced scenario in fresh state.

Export a JUnit test with assertions derived from the approved expectation, not an assertion that the buggy output is correct. Run the exported test against both implementations.

Exit: the generated search finds the known cumulative-cap defect without reading `cases.json`, the fixed `PROBE`, variant names, or expected-result labels. The reduced case reproduces; the exported test fails for the relevant assertion on the broken implementation and passes on the corrected implementation. A fixed-seed suite produces repeatable results. Infrastructure errors cannot count as discoveries.

This is the first reviewable vertical slice. Stop for product review here before broadening scope.

### 3. Test whether the mechanism generalizes

Add retry idempotency using the same execution machinery. Have an independent engineer prepare valid additional defects or select a second bounded component after the search strategy is fixed. Keep those validation cases out of generator tuning. Reject uncompilable and out-of-scope mutations from detection claims, while retaining their counts and reasons.

Compare against the component's existing test suite. Record whether Undertow found anything additional, produced a clearer reproduction, or merely restated an existing failure. An old and new implementation may legitimately differ; evaluate both against approved expectations rather than equating every difference with a bug.

Exit: another behavior works without embedding its implementation in the generator. Record adapter effort, setup problems, failures found, missed cases, non-reproducing findings, and time to understand the output. If the second adapter requires a bespoke framework, simplify or reconsider the scope.

### 4. Package a small adoption path

Only after the previous exits, expose one CLI entry point and one concise guide. Proposed command name: `undertow explore`; finalize its arguments from observed setup needs. Generate a readable local report, replay data, and a test file. Keep existing contract schemas unchanged until real usage establishes what integration is needed.

Support explicit adoption of the generated test into the user's existing suite and approved contract workflow. Draft tests do not automatically become policy. A later trusted CI execution may use the existing importer/verifier path.

Exit: an unfamiliar engineer completes setup, reproduces a failure, understands the scope, and adopts the resulting test without the author operating the tool for them. Record help needed rather than claiming a frictionless setup.

### 5. Consolidate the product around observed value

If the pilot is useful, rewrite the primary product explanation around finding reproducible behavior failures. Present one main example and one adoption route. Move specialist historical documentation out of the main reading path, preserving working references.

Evaluate optional packaging of the hosted service and other inactive features based on actual dependency coupling. Remove code only after reviewing callers, tests, and compatibility obligations. A new repository becomes an option only if extraction is demonstrably simpler than maintaining the focused workflow here.

Exit: the default user journey does not require understanding AI review, hosted credits, release gates, or rollout monitoring.

## Execution and trust constraints

The existing review tools do not execute reviewed applications. Keep that boundary: execution belongs to a separate runner selected explicitly by the host. Start only with owned, reviewed fixtures. A subprocess timeout is not a security sandbox; the prototype must not advertise support for arbitrary untrusted repositories.

Bound scenario count, sequence length, values, runtime, output, and reduction attempts. Capture immutable subject and adapter/oracle identities. Build failures must prevent reuse of stale binaries. Reset all component state and preserve enough information for deterministic replay.

Before accepting external untrusted candidates, reuse or extend the existing isolated execution path and verify credential separation, filesystem/network restrictions, resource limits, and cleanup. That is a separate acceptance gate, not a prerequisite for demonstrating the owned-fixture algorithm.

## Decision criteria

Continue when the workflow produces reproducible, understandable failures with manageable setup, and another engineer finds value beyond their existing tests. A useful result may be a missed failure or a substantially better reproduction; count those separately.

Revise when adapter authoring dominates the saved effort, the expectation cannot be observed independently, or most outputs concern execution setup rather than behavior. Narrow the supported component boundary before adding abstractions.

Stop or reposition when the workflow mainly replays handwritten examples or summarizes failures that existing CI already explains adequately. Passing the fixture tests alone is not product validation.

After the first two milestones, review actual execution time and implementation effort before scheduling the pilot. Do not commit to a larger roadmap based on estimates made before the execution/adapter boundary is understood.

## Discussion decisions

Recommended defaults for the first implementation:

1. Keep this repository and preserve the current release as the reference.
2. Start with refund caps, sequential state, and real Java execution.
3. Deliver milestones 1–2 first, then review the result together.
4. Use CLI and a local report before investing in UI.
5. Keep discovery deterministic initially; add AI only for a specific observed authoring or search limitation.

The second bounded component is now the owned ticket-transfer fixture. Independent engineer review and validation cases remain external dependencies before claiming general applicability or independent adoption; the internal second-component exercise does not supply those observations.

## References

- [Current implementation and acceptance status](ai-era-implementation-status.md)
- [Behavior preservation and monolith design](behavior-preservation-and-monoliths.md)
- [Existing refund fixture](../demo/refund-extraction/README.md)
- [Existing refund showcase generator](../scripts/refund-showcase.py)
- [AlphaProof Code introduction](https://deepmind.google/blog/introducing-alphaproof-code/)
- [AlphaProof Code technical paper](https://deepmind.google/documents/36/Formal_Verification_of_Signal_4.pdf)

The AlphaProof Code reference motivates approved specifications and independent checking. This proposal uses bounded execution and counterexample search, and makes no mathematical-proof claim.
