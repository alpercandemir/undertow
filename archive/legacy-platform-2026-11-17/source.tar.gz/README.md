<p align="center">
  <img src="docs/assets/undertow-logo.png" alt="Undertow logo" width="320" />
</p>

# Undertow

**Find a small scenario that breaks a business expectation—and keep it as a regression test.**

Undertow runs bounded operation sequences against a reviewed Java component, reduces a failing sequence, and exports its replay and JUnit test. GitHub Actions runs the checks and presents a decision summary with a proposed regression. Start with refund caps, refund retry idempotency, or ticket-transfer ownership. Search is deterministic and needs no model key.

For example, an intentionally defective refund implementation accepts a refund of **1 minor unit**, then charges **1 again when the same operation is retried**. Undertow reduces the failure to those two calls and exports a test asserting that the retry leaves the refunded total at **1**.

```mermaid
flowchart LR
    PR[Push or pull request] --> CI[Existing tests, search, replay and JUnit]
    CI --> Evidence[Actions summary and regression patch]
    Evidence --> Decision[Engineer reviews and decides]
    Decision --> Agent[Implementation agent applies accepted changes]
    Agent --> PR
```

[GitHub Actions](#review-in-github-actions) · [CI integration](docs/ci-behavior-review.md) · [Scope](#scope) · [Commands and exit codes](#commands-and-exit-codes) · [Evidence and remaining validation](#evidence-and-remaining-validation) · [Reference workflows](docs/reference-workflows.md)

## Review in GitHub Actions

The [eight-case gallery](docs/cases/README.md) adds two happy paths, five named business-rule violations and one compilation problem in a single Actions summary.

See the [successful showcase PR run](https://github.com/alpercandemir/undertow-showcase/actions/runs/44040527390) and [reviewable integration PR](https://github.com/alpercandemir/undertow-showcase/pull/3). The integration is on a draft PR branch; it has not been merged into the showcase default branch.

Open **Actions → Behavior review**, or the **Behavior review** checks on a pull request. Every push and PR runs the supported component checks automatically; **Run workflow** repeats them without a terminal. The workflow checks the exact PR head, not an implicit merge commit.

The summary answers:

- Did the existing suite pass?
- Which expectation broke, on which reduced operations, and with what expected/observed state?
- Did an exact-snapshot replay reproduce it, and did the generated JUnit assertion fail?
- What test is proposed, and what remains for the reviewer to decide?

The separate **refund-retry-calibration** job also adopts the generated test into a disposable correction and runs its full suite. It proves the automation distinguishes an authored defect from its correction; it is not the verdict for the PR component. The evidence artifact includes source identities, replay, logs, JUnit XML and a ready-to-apply `regression.patch` when a new test can be proposed.

**The engineer reviews the rule, finding and test, then requests a fix, accepts the test, or rejects the finding with reasons.** An implementation agent applies accepted changes; CI reruns. Engineers do not install tools, run replay commands or copy generated tests to demonstrate adoption.

See the [CI integration and decision guide](docs/ci-behavior-review.md) and [review criteria](docs/independent-review.md). The [CLI guide](docs/explore.md) is an optional maintainer/debugging reference.

## Scope

| Profile | Reviewed component interface | Expectations |
|---|---|---|
| `refund-cap` | `example.refunds.RefundService` | Aggregate refunds stay within capture; valid requests settle; rejection leaves state unchanged |
| `refund-retry` | The same refund component with explicit operation keys | Identical settled retries add no effects; conflicting key reuse rejects |
| `ticket-transfer` | `example.tickets.TicketTransfer` | Previews preserve state; only the recipient can accept; settled ownership remains stable |

The current adapters support sequential, in-memory, single-component Java/Maven fixtures with explicit reset. A new component needs a reviewed adapter, observable expectation and validation. Maven and Java execute as the host user; select only owned, reviewed code. The runner's time/output limits and offline builds provide bounded execution, not an untrusted-code sandbox.

The search does not call an AI model or prove correctness. A replayed failure establishes a concrete violation; a completed search with no finding establishes its observed bounded result. Concurrency, distributed effects, arbitrary repository execution and automatic business-rule discovery remain outside this workflow.

## Commands and exit codes

Use `./scripts/undertow explore --help`. Modes are `--example PROFILE`, `--subject PATH --behavior PROFILE`, `--replay FILE`, and explicit `--adopt RUN_DIRECTORY --subject PATH`. Search controls include `--seed`, `--scenarios`, `--max-length`, and `--runtime`.

| Exit | Meaning |
|---:|---|
| `0` | Completed search without a counterexample within budget, or successful explicit draft adoption |
| `1` | Reproduced counterexample; inspect the report and generated test |
| `2` | Usage/setup/execution problem or unfinished work; any verified original finding is reported separately |

The packaged JAR exposes the same command and bundles its Python runner, adapters and owned examples. It requires JDK 25 to launch, Python 3.10+ and Maven, with an explicit JDK 21+ for component execution:

```sh
java -jar target/undertow.jar explore --example refund-retry \
  --java-home "$JAVA_HOME" --output .undertow/packaged-example
```

Other existing CLI commands retain their exit codes and execution boundaries; see the [reference command table](docs/reference-workflows.md#commands-and-exit-codes).

## Evidence and remaining validation

The [milestones 1–3 execution record](docs/behavior-counterexample-plan.md) records actual Java execution, reduction, replay and paired JUnit exports. In the internal authored validation set, five eligible defects reproduced across three locked seeds. Three expose failures in variants that pass their existing suites. Compilation failures, unsuitable implementations and out-of-scope requests remain separate from detection counts.

These are small, self-authored fixtures. CI execution replaces the earlier manual onboarding exercise. Independent owner review and observed value on real changes remain open: automation cannot supply those judgments. Read the [milestone 3 provenance](experiments/behavior-search/MILESTONE-3.md) and [review procedure](docs/independent-review.md).

## Development

The harness uses JDK 25; fixture execution targets Java 21. For maintainers working on the implementation, with the fixture cache prepared:

```sh
JAVA_HOME=/path/to/jdk-25 mvn --batch-mode --no-transfer-progress verify
python3 -m unittest discover -s scripts/tests -v
```

The [contribution guide](CONTRIBUTING.md) contains formatting, application-demo and security checks. Search code remains under `experiments/behavior-search/`; packaging leaves its frozen milestone 3 core unchanged.

Existing contract verification, read-only MCP, CI import, optional AI investigation, hosted preview and advanced assurance are retained. See [reference workflows](docs/reference-workflows.md), [architecture](docs/architecture.md), [contracts and trust](docs/contracts.md), [advanced assurance](docs/assurance.md), and the [historical implementation status](docs/ai-era-implementation-status.md). The [recorded interactive demo](demo/pr-workbench/README.md) remains available as a separate browser-model demonstration.
